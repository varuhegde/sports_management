    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
     
      <ul class="app-menu">
        <li><a class="app-menu__item" href="home.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label ">Dashboard</span></a></li>
        <li><a class="app-menu__item" href="material_view.php"><i class="app-menu__icon fa fa-pie-chart"></i>Material Details<span class="app-menu__label"></span></a></li>
		<li><a class="app-menu__item" href="vendor_view.php"><i class="app-menu__icon fa fa-pie-chart"></i>Vendor Details</a></li>
        <li><a class="app-menu__item" href="purchase_material_view.php"><i class="app-menu__icon fa fa-pie-chart"></i>Purchase Material <span class="app-menu__label"></span></a></li>
		<li><a class="app-menu__item" href="pd_details_view.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Physical Director Details </span></a></li>
		 <li><a class="app-menu__item" href="sports_view.php"><i class="app-menu__icon fa fa-pie-chart"></i>Sports Details</a></li>
		<li><a class="app-menu__item" href="achievements_view.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Achievements Details</span></a></li>
		<li><a class="app-menu__item" href="facility_view.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label"> Facility Details</span></a></li>
		<li><a class="app-menu__item" href="event_view.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Event Details</span></a></li>
		<li><a class="app-menu__item" href="branch_view.php"><i class="app-menu__icon fa fa-pie-chart"></i>Branch Details</a></li>
		<li><a class="app-menu__item" href="student_view.php"><i class="app-menu__icon fa fa-pie-chart"></i>Student Details</a></li>
		<li><a class="app-menu__item" href="event_request_view.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label"> Event Request Details</span></a></li>
	    <li><a class="app-menu__item" href="material_issue_view.php"><i class="app-menu__icon fa fa-pie-chart"></i>Material Issue Details</a></li>
		<li><a class="app-menu__item" href="stock_view.php"><i class="app-menu__icon fa fa-pie-chart"></i>Stock Details</a></li>
		<li><a class="app-menu__item" href="change pwd.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Change password</span></a></li>
		<li><a class="app-menu__item" href="../logout.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Logout</span></a></li>
        
        
       
        
       
      </ul>
    </aside>