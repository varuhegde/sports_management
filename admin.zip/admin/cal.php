<?php
require_once('calendar/classes/tc_calendar.php');
?>
<link href="calendar/calendar.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="calendar/calendar.js"></script>
