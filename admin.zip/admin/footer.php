    <footer class="footer text-center">
                All Rights Reserved by KLE-SPORTS. Designed and Developed by : <a href="#">Praveen and Varun</a>.
            </footer>